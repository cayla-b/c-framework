#include "test1.h"
#include "test1_r.h"
#include "module/test2.h"
#include "module/test2_r.h"
#include <stdio.h>

static void static_test1_function(void);

int test1_main(int argc, char * argv[]) {
    printf("Call MAIN_MOD1\n");
    
    private_test1_function();
    printf("From MAIN_MOD1\n");
    public_test1_function();
    printf("From MAIN_MOD1\n");
    static_test1_function();
    printf("From MAIN_MOD1\n");

    private_test2_function();
    printf("From MAIN_MOD1\n");
    public_test2_function();
    printf("From MAIN_MOD1\n");

    return 0;
}

void public_test1_function(void) {
    printf("Call public_test1_function : ");
}

void private_test1_function(void) {
    printf("Call private_test1_function : ");
}

static void static_test1_function(void) {
    printf("Call static_test1_function : ");
}
