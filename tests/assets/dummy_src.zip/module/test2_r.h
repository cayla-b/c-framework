#ifndef __TEST2_R_H
#define __TEST2_R_H

extern void private_test2_function(void);

#endif /* __TEST2_R_H */
