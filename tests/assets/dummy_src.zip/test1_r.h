#ifndef __TEST1_R_H
#define __TEST1_R_H

extern void private_test1_function(void);

#endif /* __TEST1_R_H */
